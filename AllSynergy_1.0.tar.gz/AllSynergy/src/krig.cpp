//Includes/namespaces
#include <Rcpp.h>
using namespace Rcpp;

//' @export
// [[Rcpp::export]]
std::vector< std::vector<double> > krig(std::vector<int> xseq, std::vector<double> kriged, std::vector<int> a,
               std::vector<int> yseq, std::vector<int> b, int z_len, std::vector<double> res1,
               int na, int nb, std::vector<double> res2) {
                     std::vector< std::vector<double> > v;
                     int indx_;     
                     for(int idx1 = 1; idx1 <= na; idx1++) {
                     for(int idx2 = 1; idx2 <= nb; idx2++) {  
                     for (int idx3 = 1; idx3 <= z_len; idx3++){
                     if(xseq[idx3 - 1] == a[idx1 - 1] && yseq[idx3 - 1] == b[idx2 - 1]) {
                     indx_ = idx2 + (idx1 - 1)*nb - 1;
                     res1[indx_] = kriged[idx3 - 1];
                     res2[indx_] = 1.0;
                     //printf("Hi%i", indx_);
                     break;
                     }
                     }
                     }
                     }
                     v.push_back(res1); v.push_back(res2);
                     return v ;
 }
