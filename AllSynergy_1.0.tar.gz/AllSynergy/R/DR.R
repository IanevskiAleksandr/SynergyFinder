

#data = getData()  i = 1
PlotDoseResponseShinyDR <- function (data, param = "inhibition", i, paramplot = 1) {
  if(!is.list(data)) {
    stop("Input data is not a list format!")
  }
  
  plot(0,type='n',axes=FALSE,ann=FALSE) ## avoiding plot.new error
  dose.response.mats <- data$dose.response.mats
  drug.pairs <- data$drug.pairs
  
  response.mat <- dose.response.mats[[i]]
  
  num.pairs <- length(dose.response.mats)
  num.row <- length(response.mat)
  data.plot <- data.frame(x = numeric(num.row), y = numeric(num.row),
                          Inhibition = numeric(num.row))
  data.plot$Inhibition <- round(c(response.mat), 2)
  
  nrowrm = nrow(response.mat)
  ncolrm = ncol(response.mat)
  
  # data.plot$y <- rep(c(1:nrowrm), ncolrm)
  # data.plot$x <- rep(1:ncolrm, each = nrowrm)
  # data.plot$x <- as.factor(data.plot$x)
  # data.plot$y <- as.factor(data.plot$y)
  data.plot$y <- rep(c(1:ncol(response.mat)), nrow(response.mat))
  data.plot$x <- rep(1:nrow(response.mat), each = ncol(response.mat))
  data.plot$x <- as.factor(data.plot$x)
  data.plot$y <- as.factor(data.plot$y)
  
  conc.unit <- drug.pairs$concUnit[i] ## concentration unit
  unit.text <- paste("(", conc.unit, ")", sep = "")
  drug.row <- drug.pairs$drug.row[i]
  drug.col <- drug.pairs$drug.col[i]
  plot.title <- paste("\n\nDose-response matrix (", tolower(param), ")\n", sep="")
  
  
  if (paramplot == 1)
  {
    # plot dose-response matrix
    axis.x.text <- round(as.numeric(colnames(response.mat)), 1)
    axis.y.text <- round(as.numeric(rownames(response.mat)), 1)
    
    dose.response.p <- ggplot(data.plot, aes_string(x = "x", y = "y")) + geom_tile(aes_string(fill = 'Inhibition')) +
      theme(title = element_text(face = "bold", size = 10))+
      geom_text(aes_string(fill = 'Inhibition', label = 'Inhibition'), size=3.5) +
      scale_fill_gradient2(low = "green", high = "red", midpoint = 0, name = paste0(param, " (%)")) +
      scale_x_discrete(labels = axis.x.text) + scale_y_discrete(labels = axis.y.text) +
      xlab(paste(drug.col, unit.text, sep = " ")) + ylab(paste(drug.row, unit.text, sep = " "))
    #print(axis.x.text[xl[1]:xl[2]])
    
    dose.response.p <- dose.response.p + theme(axis.text.x = element_text(color = "red", face = "bold", size = 10))
    dose.response.p <- dose.response.p + theme(axis.text.y = element_text(color = "red", face = "bold", size = 10))
    dose.response.p <- dose.response.p + theme(axis.title = element_text(size=10))
    dose.response.p <- dose.response.p + ggtitle(plot.title)
    
    print(dose.response.p, newpage = F)
    mtext(paste(drug.col," & ",drug.row, "     "), outer=TRUE,  cex=1.3, line=-1.5, col = "blue")
  }
  else
    if (paramplot == 2)
    {
      single.fitted <- FittingSingleDrug(response.mat)
      # plot the curve for the row drug
      suppressWarnings(par(mgp=c(3, .5, 0)))
      x.lab <- paste("Concentration", unit.text, sep = " ")
      #par(mar = c(0, 0, 4.5, 0))
      par(mar = c(5.5, 5, 6.5, 2.5))
      plot(single.fitted$drug.row.model, xlab = x.lab, ylab = paste0(param, " (%)"), type = "obs", col = "red", cex = 1.5, pch = 16, xtsty = "base5")
      #par(mar = c(3, 0, 0, 0))
      plot(single.fitted$drug.row.model, xlab = x.lab, ylab = paste0(param, " (%)"), type = "none", cex = 1.5, add = T, lwd = 3)
      
      par(mar = c(0, 1, 9, 0))
      title(paste("Dose-response curve for drug:", drug.row), cex.main = 1)
    }
  
  else
    if (paramplot == 3)
    {
      single.fitted <- FittingSingleDrug(response.mat)
      # plot the curve for the col drug
      suppressWarnings(par(mgp=c(3, .5, 0)))
      x.lab <- paste("Concentration", unit.text, sep = " ")
      par(mar = c(5.5, 5, 6.5, 2.5))
      plot(single.fitted$drug.col.model, xlab = x.lab, ylab = paste0(param, " (%)"), type = "obs", col = "red", cex = 1.5, pch = 16, xtsty = "base5")
      plot(single.fitted$drug.col.model, xlab = x.lab, ylab = paste0(param, " (%)"), type = "none", cex = 1.5, add = T, lwd = 3)
      par(mar = c(0, 1, 9, 0))
      title(paste("Dose-response curve for drug:", drug.col), cex.main = 1)
    }
}


#plot.new()
#PlotDoseResponseShinyDR(getData(), "viability", 1,1 , c(2, 4), c(2, 4) )
