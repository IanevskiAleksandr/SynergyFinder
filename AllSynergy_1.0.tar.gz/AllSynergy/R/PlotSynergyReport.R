
PlotSynergyReport <- function(data, type = "2D"){
  if(!is.list(data)) {
    stop("Input data is not a list format!")
  }
  texfile <- 'result.tex'
  latexBegin <- "\\documentclass{article}
  \\usepackage[papersize={7in,7in},margin=0.3in]{geometry}
  \\usepackage{animate}
  \\usepackage{pdfpages}
  \\begin{document}\\includepdf[pages=-]{./first0.pdf}\\newpage\\includepdf[pages=-]{./first1.pdf}\\newpage"
  zz <- 0
  scores <- data$scores
  drug.pairs <- data$drug.pairs
  num.pairs <- length(scores)
  plots <- list()
  for (i in 1:num.pairs){
    scores.dose <- t(scores[[i]])
    drug.col <- drug.pairs$drug.col[i]
    drug.row <- drug.pairs$drug.row[i]
    summary.score <- round(mean(scores.dose[-1, -1]), 3)
    # drug.col: the col-wise drug
    # drug.row: the row-wise drug
    x.conc <- as.numeric(rownames(scores.dose))  ## col-wise drug concentration
    y.conc <- as.numeric(colnames(scores.dose))  ## row-wise drug concentration
    
    # drug.col.conc in index
    x <- c(0:(length(x.conc) - 1))
    # drug.row.conc in index
    y <- c(0:(length(y.conc) - 1))
    
    # smoothing by kriging
    tmp <- cbind(expand.grid(x, y),c(as.matrix(scores.dose)))
    x.vec <- tmp[, 1]
    y.vec <- tmp[, 2]
    scores.dose.vec = tmp[, 3]
    #kriged = kriging(x.vec,y.vec,delta.dose.vec,lags=3,pixels=50)
    pixels.num <- 5 * (length(x.conc) - 1) + 2
    if (dim(scores.dose)[1] < 8) {
      kriged <- kriging(x.vec, y.vec, scores.dose.vec,lags = 2, pixels = pixels.num, model = "spherical")
    } else {
      kriged <- kriging(x.vec, y.vec, scores.dose.vec,lags = 3, pixels = pixels.num, model = "spherical")
    }
    xseq <- round(kriged[["map"]]$x / kriged$pixel)
    yseq <- round(kriged[["map"]]$y / kriged$pixel)
    a <- min(xseq):max(xseq)
    b <- min(yseq):max(yseq)
    z.len <- length(kriged[["map"]]$pred) ## n
    na <- length(a)
    nb <- length(b)
    res1 <- as.double(rep(0, na * nb)) ## c
    res2 <- as.integer(rep(0,na * nb)) ## d
    for(idx1 in 1:na) {
      for(idx2 in 1:nb) {
        for(idx3 in 1:z.len) {
          if(xseq[idx3] == a[idx1] && yseq[idx3] == b[idx2]) {
            res1[idx2+(idx1-1)*nb] <- kriged[["map"]]$pred[idx3]
            res2[idx2+(idx1-1)*nb] <- 1
            break
          }
        }
      }
    }
    res1[res2 == 0] <- NA
    c <- matrix(res1, na, nb, byrow = TRUE)
    plot.title <- paste(data$method,"synergy score:", summary.score, sep = " ")
    
    conc.unit <- drug.pairs$concUnit[i] ## concentration unit
    unit.text <- paste("(", conc.unit, ")", sep = "")
    file.name <- paste(drug.row, drug.col, "synergy", drug.pairs$blockIDs[i], data$method, "pdf", sep = ".")
    drug.row <- paste(drug.row, unit.text, sep = " ")
    drug.col <- paste(drug.col, unit.text, sep = " ")
    max.dose <- max(abs(max(scores.dose)), abs(min(scores.dose)))
    color.range <- round(max.dose + 5, -1)
    start.point <- -color.range
    end.point <- color.range
    
    
    if(type == "3D"){
      
      zz = zz + 1
      

        pdf(paste(LETTERS[zz], ".pdf", sep=""), width = 7.0, height = 7.0, onefile = T)
        plot(0,type='n',axes=FALSE,ann=FALSE)
        
        fig <- wireframe(c, scales = list(arrows = FALSE,distance = c(0.8,0.8,0.8),col=1,cex=0.8,z = list(tick.number=7),x=list(at=seq(0, pixels.num, 5),labels=round(x.conc, 3)),y=list(at=seq(0,pixels.num,5),labels=round(y.conc,3))),
                         drape = TRUE, colorkey = list(space="top",width=0.5),
                         #screen = list(z = 30, x = -55),
                         screen = list(z = 30, x = -55),
                         zlab = list(expression(delta ~ -score),rot=90,cex=1,axis.key.padding = 0),
                         xlab=list(as.character(drug.col),cex=1, rot=20),ylab=list(as.character(drug.row),cex=1,rot=-50),
                         zlim = c(start.point, end.point),
                         col.regions=colorRampPalette(c("green","white","red"))(100),
                         main = plot.title,
                         at=do.breaks(c(start.point, end.point),100),
                         par.settings = list(axis.line=list(col="transparent"),
                                             layout.widths=list(left.padding=0,right.padding=0), layout.heights=list(top.padding=8, bottom.padding=0)),
                         zoom = 0.9
                         #par.settings=list(layout.widths=list(left.padding=0,right.padding=0), layout.heights=list(top.padding=0, bottom.padding=0)) # margin
        )
        
        
        print(fig, position = c(0,0, 1, 1), newpage = F)
        
        
        #grid::grid.text(paste("x - ", drug.col,sep=""), x=unit(0.86, "npc"), y=unit(0.14, "npc"), gp = gpar(fontsize = 12, fontface = "bold", col = "blue"))
        #grid::grid.text(paste("y - ", drug.row,sep=""), x=unit(0.86, "npc"), y=unit(0.12, "npc"), gp = gpar(fontsize = 12, fontface = "bold", col = "blue"))
        
        mtext(paste(drug.col," & ",drug.row), outer=TRUE,  cex=1.4, line=-1.7, col = "blue")
        
        graphics.off()
        
    } else if (type == "2D") { 
      zz = zz+1
      pdf(paste(LETTERS[zz], ".pdf", sep=""), width = 7.0, height = 7.0, onefile = T)
      
      
      # par(mar = c(0, 7, 7.1, 2.1))
      # suppressWarnings(par(mgp = c(3, -0.4, 0)))
      # levels <- seq(start.point, end.point, by = 2)
      # col <- colorpanel(end.point, low = "green", mid = "white", high = "red")
      # plot.new()
      # par(mar = c(35.2, 7.1, 5, 4.1))
      # plot.window(ylim = c(0, 1), xlim = range(levels), xaxs = "i", yaxs = "i")
      # #par(mar = c(20, 6.1, 4.5, 4.1))
      # par(mar = c(32.2, 7.1, 5, 4.1))
      # rect(levels[-length(levels)],0, levels[-1L],0.3, col = col, border = NA)
      # par(mar = c(5.1, 7.1, 5.5, 4.1))
      # axis(3,tick = F, at = do.breaks(c(start.point, end.point), end.point/10), cex.axis=0.8)
      # par(mar = c(5.1, 7.1, 7, 4.1))
      # title(plot.title)
      # suppressWarnings(par(mgp = c(2,1,0)))
      # #plot.new()
      # x.2D <- (1:dim(c)[1] - 1) / (dim(c)[1] - 1)
      # y.2D <- (1:dim(c)[2] - 1) / (dim(c)[2] - 1)
      # 
      # par(mar = c(7.1,7.1,8.1,4.1))
      # suppressWarnings(par(mgp = c(3, 0.5, 0)))
      # plot.window(asp = NA, xlim = range(x.2D), ylim = range(y.2D), "", xaxs = "i", yaxs = "i")
      # .filled.contour(x.2D, y.2D, z = c, levels, col = col)
      # ###grid(dim(c)[1] - 1, dim(c)[2] - 1, col = "gray", lty = "solid", lwd = 0.3)
      # par(mar = c(7.1,7.1,8.1,4.1))
      # box()
      # mtext(drug.col, 1, cex = 1, padj = 3)
      # mtext(drug.row, 2, cex = 1, las = 3, padj = -3)
      # axis(side = 1, at = seq(0, 1, by = 1/(length(x.conc) - 1 )), labels = round(x.conc, 1),cex.axis=0.8)
      # axis(side = 2, at = seq(0, 1, by = 1/(length(x.conc) - 1 ))[-1], labels = round(y.conc[-1], 1), cex.axis=0.8)
      # 
      plot2d = melt(c) 
      
      myPalette <- colorRampPalette(c("green2","white","red1"))(100)
      names(plot2d) <- c("x", "y", "z")
      
      
      gg2d = ggplot(plot2d) + aes(x, y, z = z, fill = z)+
        ggtitle(plot.title) + theme(plot.title = element_text(size=22, margin=margin(b = 50, unit = "pt"))) +
        #scale_fill_gradient2(, "\U0394 - score",low=rgb(0,255,0, maxColorValue = 255), high=rgb(255,0, 0,  maxColorValue = 255), guide="colorbar") + 
        geom_raster(interpolate=TRUE) + geom_contour(color = "white", alpha = 0.5) +
        scale_fill_gradientn("\U03B4 - score",colours = myPalette, limits=c(start.point, end.point), values = rescale(c(-3, -1, 0, 1, 3))) +
        scale_x_continuous(drug.col, expand = c(0,0),
                           breaks = seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), labels = round(x.conc, 1)) + 
        scale_y_continuous(drug.row, expand = c(0,0),
                           breaks = seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), labels = round(y.conc, 1)) +
        geom_vline(xintercept=seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), linetype="dotted", size = 0.25) +
        geom_hline(yintercept=seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), linetype="dotted", size = 0.25) +
        theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                           panel.grid.minor = element_blank()) +theme(axis.text=element_text(size=10)) +
        theme(axis.title.y=element_text(margin=margin(0,20,0,0))) +
        theme(plot.margin=unit(c(1,1,1.5,1.2),"cm"))
      
      plot(0,type='n',axes=FALSE,ann=FALSE)
      print(gg2d, newpage = F)
      mtext(paste(drug.col," & ",drug.row, "     "), outer=TRUE,  cex=1.3, line=-1.5, col = "blue")
      #mtext(paste(drug.col," vs ",drug.row), outer=TRUE,  cex=1.4, line=-1.3, col = "blue")
      graphics.off()
    } else {
      zz = zz + 1

        pdf(paste(LETTERS[zz], ".pdf", sep=""), width = 7.0, height = 7.0, onefile = T)
        
        syn.3d.plot <- wireframe(c,scales = list(arrows = FALSE,distance=c(0.8,0.8,0.8),col=1,cex=0.65,z = list(tick.number=7),x=list(at=seq(0, pixels.num, 5),labels=round(x.conc, 1)),y=list(at=seq(0,pixels.num,5),labels=round(y.conc,1))),
                                 drape = TRUE, colorkey = list(space="top",width=0.5, col=colorRampPalette(c("green","white","red"))(100), at=do.breaks(c(start.point, end.point),100)),
                                 
                                 screen = list(z = 30 , x = -55),
                                 zlab=list(expression(delta ~ -score),rot=95,cex=0.9,axis.key.padding = 10),
                                 xlab=list(as.character(drug.col),cex=1, rot=20),ylab=list(as.character(drug.row),cex=1,rot=-50),
                                 zlim=c(start.point, end.point),
                                 col.regions=colorRampPalette(c("green","white","red"))(100),
                                 
                                 main = plot.title,
                                 at=do.breaks(c(start.point, end.point),100),
                                 par.settings = list(axis.line=list(col="transparent"), layout.widths=list(left.padding=0,right.padding=0), layout.heights=list(top.padding=0, bottom.padding=0)),
                                 zoom = 0.92
                                 #par.settings=list(layout.widths=list(left.padding=0,right.padding=0), layout.heights=list(top.padding=0, bottom.padding=0)) # margin
        ) 
        #layout(matrix(c(1, 2, 3, 3), nrow = 2L, ncol = 2L), heights = c(0.1, 1))
        par(mar = c(0, 2.1, 2.1, 2.1))
        suppressWarnings(par(mgp = c(3, -0.4, 0)))
        levels <- seq(start.point, end.point, by = 2)
        col <- colorpanel(end.point, low = "green", mid = "white", high = "red")
        plot.new()
        par(mar = c(29.2, 4.1, 5, 19.1))
        plot.window(ylim = c(0, 1), xlim = range(levels), xaxs = "i", yaxs = "i")
        #par(mar = c(20, 6.1, 4.5, 4.1))
        rect(levels[-length(levels)],0, levels[-1L],0.3, col = col, border = NA)
        par(mar = c(5.1, 4.1, 5, 19.1))
        axis(3,tick = F, at = do.breaks(c(start.point, end.point), end.point/10), cex.axis=0.8)
        par(mar = c(5.1, 4.1, 8, 19.1))
        title(plot.title)
        suppressWarnings(par(mgp = c(2,1,0)))
        #plot.new()
        x.2D <- (1:dim(c)[1] - 1) / (dim(c)[1] - 1)
        y.2D <- (1:dim(c)[2] - 1) / (dim(c)[2] - 1)
        
        par(mar = c(7.1,3,7.1,18.1))
        suppressWarnings(par(mgp = c(3, 0.5, 0)))
        plot.window(asp = NA, xlim = range(x.2D), ylim = range(y.2D), "", xaxs = "i", yaxs = "i")
        .filled.contour(x.2D, y.2D, z = c, levels, col = col)
        ###grid(dim(c)[1] - 1, dim(c)[2] - 1, col = "gray", lty = "solid", lwd = 0.3)
        par(mar = c(7.1,3,7.1,18.1))
        box()
        mtext(drug.col, 1, cex = 1, padj = 3)
        mtext(drug.row, 2, cex = 1, las = 3, padj = -3)
        axis(side = 1, at = seq(0, 1, by = 1/(length(x.conc) - 1 )), labels = round(x.conc, 1),cex.axis=0.8)
        axis(side = 2, at = seq(0, 1, by = 1/(length(x.conc) - 1 ))[-1], labels = round(y.conc[-1], 1), cex.axis=0.8)
        #par(mar = c(2,2,2,7))
        print(syn.3d.plot, position = c(0.5,0, 1, 1), newpage = FALSE)
        #grid::grid.text(paste("x - ", drug.col,sep=""), x=unit(0.86, "npc"), y=unit(0.2, "npc"), gp = gpar(fontsize = 12, fontface = "bold", col = "blue"))
        #grid::grid.text(paste("y - ", drug.row,sep=""), x=unit(0.86, "npc"), y=unit(0.18, "npc"), gp = gpar(fontsize = 12, fontface = "bold", col = "blue"))
        mtext(paste(drug.col," & ",drug.row), outer=TRUE,  cex=1.3, line=-1.3, col = "blue")
        
        graphics.off()
      
    }
   
    
    #check for last page
    if (i!=num.pairs)
      
      latexBegin <- paste(latexBegin, "\\includepdf[pages=-]{./",paste0(LETTERS[zz], ".pdf"),"}\\newpage", sep="")
    else
      latexBegin <- paste(latexBegin, "\\includepdf[pages=-]{./",paste0(LETTERS[zz], ".pdf"),"}", sep="")
    
  }
  
  latexBegin <- paste(latexBegin, "\\end{document}", sep='')
  cat(latexBegin, sep='', file=texfile)
  system(paste0('pdflatex ', '-output-directory ./ ', texfile))
}
