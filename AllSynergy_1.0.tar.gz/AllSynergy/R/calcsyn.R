calcsyn <- function(data, i)
{
  # ptm <- proc.time()
  scores <- data$scores
  drug.pairs <- data$drug.pairs
  num.pairs <- length(scores)
  
  scores.dose <- t(scores[[i]])
  drug.col <- drug.pairs$drug.col[i]
  drug.row <- drug.pairs$drug.row[i]
  summary.score <- round(mean(scores.dose[-1, -1]), 3)
  
  x.conc <- as.numeric(rownames(scores.dose))  ## col-wise drug concentration
  y.conc <- as.numeric(colnames(scores.dose))  ## row-wise drug concentration
  
  # drug.col.conc in index
  x <- c(0:(length(x.conc) - 1))
  # drug.row.conc in index
  y <- c(0:(length(y.conc) - 1))
  
  
  
  # smoothing by kriging
  tmp <- cbind(expand.grid(x, y),c(as.matrix(scores.dose)))
  x.vec <- tmp[, 1]
  y.vec <- tmp[, 2]
  scores.dose.vec = tmp[, 3]
  #kriged = kriging(x.vec,y.vec,delta.dose.vec,lags=3,pixels=50)
  pixels.num <- 5 * (length(x.conc) - 1) + 2
  if (dim(scores.dose)[1] < 8) {
    kriged <- kriging(x.vec, y.vec, scores.dose.vec,lags = 2, pixels = pixels.num, model = "spherical")
  } else {
    kriged <- kriging(x.vec, y.vec, scores.dose.vec,lags = 3, pixels = pixels.num, model = "spherical")
  }
  xseq <- round(kriged[["map"]]$x / kriged$pixel)
  yseq <- round(kriged[["map"]]$y / kriged$pixel)
  a <- min(xseq):max(xseq)
  b <- min(yseq):max(yseq)
  z.len <- length(kriged[["map"]]$pred) ## n
  na <- length(a)
  nb <- length(b)
  res1 <- as.double(rep(0, na * nb)) ## c
  res2 <- as.integer(rep(0,na * nb)) ## d
  
  # print(paste0("first",proc.time() - ptm))
  #  ptm <- proc.time()
  
  #     
  #     for(idx1 in 1:na) {
  #       for(idx2 in 1:nb) {
  #         for(idx3 in 1:z.len) {
  #           if(xseq[idx3] == a[idx1] && yseq[idx3] == b[idx2]) {
  #             indx_ = idx2+(idx1-1)*nb;
  #             res1[indx_] <- kriged[["map"]]$pred[idx3]
  #             res2[indx_] <- 1
  #             break
  #           }
  #         }
  #       }
  #     }
  
  res = krig(xseq = xseq, kriged = kriged[["map"]]$pred, a = a, yseq = yseq, b = b, z_len = z.len, res1 = res1, na = na, nb = nb, res2 = res2)
  res1 = res[[1]]; res2 = res[[2]];
  
  #print(paste0("second",proc.time() - ptm))
  #ptm <- proc.time()
  
  res1[res2 == 0] <- NA
  c <- matrix(res1, na, nb, byrow = TRUE)
  
  
  conc.unit <- drug.pairs$concUnit[i] ## concentration unit
  unit.text <- paste0("(", conc.unit, ")")
  #file.name <- paste(drug.row, drug.col, "synergy", drug.pairs$blockIDs[i], data$method, "pdf", sep = ".")
  drug.row <- paste(drug.row, unit.text, sep = " ")
  drug.col <- paste(drug.col, unit.text, sep = " ")
  max.dose <- max(abs(max(scores.dose)), abs(min(scores.dose)))
  color.range <- round(max.dose + 5, -1)
  start.point <- -color.range
  end.point <- color.range
  
  
  return (list(c = c, conc.unit = conc.unit, drug.row = drug.row, drug.col = drug.col, 
               start.point = start.point, end.point = end.point,
               summary.score = summary.score, x.conc = x.conc, y.conc = y.conc))
}