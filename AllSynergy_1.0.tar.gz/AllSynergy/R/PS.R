
#' library(synergyfinder); data("mathews_screening_data"); data <- ReshapeData(mathews_screening_data);  scores <- CalculateSynergy(data); data = scores; i = 1  
#' PlotSynergy(scores, "all")

PlotSynergyShiny <- function(data, type = "2D", graphnumber = 1, brushx = NULL, brushy = NULL, gridsize = 1, gridsize2 = 0, savee2D = NULL, savee3D = NULL, newscore = NULL, name_3D = NULL, method_ = "ZIP"){
  if(!is.list(data)) {
    stop("Input data is not a list format!")
  }

  if(gridsize == -1){
    colmap = TRUE
    gridsize = 1
  }
  else{
    colmap = FALSE
  }
  
  summary.score <- data$summary.score
  drug.row <- data$drug.row
  drug.col <- data$drug.col
  c <- data$c
  x.conc <- data$x.conc
  y.conc <- data$y.conc
  start.point <- data$start.point
  end.point <- data$end.point
  
  if(method_ == "ZIP")
  {
    if(!is.null(newscore))
    {
      plot.title <- bquote(~ delta ~ " - score: " ~ .(newscore)) #paste("\U03B4 - score:", summary.score, sep = " ")
      plot.title2 <- bquote(~ delta ~ " - score: " ~ .(newscore)) #paste("\U03B4 - score:", summary.score, sep = " ")
    }
    else
    {
      plot.title <- bquote(~ delta ~ " - score: " ~ .(summary.score)) #paste("\U03B4 - score:", summary.score, sep = " ")
      plot.title2 <- paste("delta score:", summary.score, sep = " ") #expression(delta ~ -score)
    }
    title3D = paste(drug.row, "&", drug.col, "<br>\U03B4 - score:", summary.score, sep = " ")
  }
  else
  {
    if(!is.null(newscore))
    {
      plot.title <- paste0(method_, " synergy score: ", newscore)
      plot.title2 <- paste0(method_, " synergy score: ", newscore) #paste("\U03B4 - score:", summary.score, sep = " ")
    }
    else
    {
      plot.title <- paste0(method_, " synergy score: ", summary.score) #paste("\U03B4 - score:", summary.score, sep = " ")
      plot.title2 <- paste0(method_, " synergy score: ", summary.score) #expression(delta ~ -score)
    }
    title3D = paste(drug.row, "&", drug.col, "<br>", method_, "synergy score:", summary.score, sep = " ")
  }
  

  print(paste0("size- ",gridsize))
  
  if (graphnumber == 1 && gridsize!=0)
  {
    aaa <- xyzmat.coords(c) 
    lenx = length(aaa$x) 
    leny = length(aaa$y) 
    subX = seq.int(min(x.conc), max(x.conc), length.out = lenx) 
    subY = seq.int(max(y.conc), min(y.conc), length.out = leny) 
    
    #print(paste0("third",proc.time() - ptm))
    
    if(is.null(savee3D))
    {
      
      plot_ly(z = c,x = subX, y = subY, type = "surface", 
              
              contours = list(
                y = list(show = TRUE, width = gridsize, highlightwidth = 2, usecolormap = colmap),
                x = list(show = TRUE, width = gridsize, highlightwidth = 2, usecolormap = colmap)
              ), 
              
              hoverinfo='z+name', name = "\U03B4 - score",
              
              colorbar = list( 
                outlinewidth = 0, 
                title = "\U03B4 - score",
                len = 0.24,
                thickness = 19,
                xpad = 3,
                showticklabels = TRUE,
                titlefont = 9,
                outlinewidth = 0.3,
                tickcolor = "#fff",
                tickfont = list(size = 9),
                ticks = "inside"
              ), 
              colorscale = list(c(0, "rgb(0, 247, 0)"), c(0.5, "rgb(247, 247, 247)"), c(1, "rgb(247, 0, 0)")), 
              cauto = F, 
              cmin = start.point, 
              cmax = end.point,
              contour = list(show = FALSE, color = "#222")
              
      ) %>% 
        layout(
          title = title3D, 
          scene = list( 
            xaxis = list( 
              title = as.character(drug.row), 
              tickmode = "array", 
              tickvals = seq.int(min(x.conc), max(x.conc), length.out = length(x.conc)), 
              tickfont = list(family = "serif", size = 12), ticks = "outside", 
              ticktext = as.character(y.conc) 
            ), 
            yaxis = list( 
              title = as.character(drug.col), 
              tickmode = "array", 
              tickvals = seq.int(max(y.conc), min(y.conc), length.out = length(y.conc)), 
              tickfont = list(family = "serif", size = 12), ticks = "outside", 
              ticktext = as.character(x.conc) 
            ), 
            zaxis = list( 
              title =  "\U03B4 - score", 
              range = c(start.point, end.point), 
              tickfont = list(family = "serif", size = 12), ticks = "outside" 
            ) 
          ) 
        )
    }
    else
    {
      p = plot_ly(z = c,x = subX, y = subY, type = "surface", 
                  
                  contours = list(
                    y = list(show = TRUE, width = gridsize, highlightwidth = 2, usecolormap = colmap),
                    x = list(show = TRUE, width = gridsize, highlightwidth = 2, usecolormap = colmap)
                  ), 
                  
                  hoverinfo='z+name', name = "\U03B4 - score",
                  
                  colorbar = list( 
                    outlinewidth = 0, 
                    title = "\U03B4 - score",
                    len = 0.24,
                    thickness = 19,
                    xpad = 3,
                    showticklabels = TRUE,
                    titlefont = 9,
                    outlinewidth = 0.3,
                    tickcolor = "#fff",
                    tickfont = list(size = 9),
                    ticks = "inside"
                  ), 
                  colorscale = list(c(0, "rgb(0, 247, 0)"), c(0.5, "rgb(247, 247, 247)"), c(1, "rgb(247, 0, 0)")), 
                  cauto = F, 
                  cmin = start.point, 
                  cmax = end.point,
                  contour = list(show = FALSE, color = "#222")
      ) %>% 
        layout(
          title = title3D, 
          scene = list( 
            xaxis = list( 
              title = as.character(drug.row), 
              tickmode = "array", 
              tickvals = seq.int(min(x.conc), max(x.conc), length.out = length(x.conc)), 
              tickfont = list(family = "serif", size = 12), ticks = "outside", 
              ticktext = as.character(y.conc) 
            ), 
            yaxis = list( 
              title = as.character(drug.col), 
              tickmode = "array", 
              tickvals = seq.int(max(y.conc), min(y.conc), length.out = length(y.conc)), 
              tickfont = list(family = "serif", size = 12), ticks = "outside", 
              ticktext = as.character(x.conc) 
            ), 
            zaxis = list( 
              title =  "\U03B4 - score", 
              range = c(start.point, end.point), 
              tickfont = list(family = "serif", size = 12), ticks = "outside" 
            ) 
          ) 
        )
      htmlwidgets::saveWidget(as.widget(p), name_3D)
    }
    
  } 
  else if (graphnumber == 1 && gridsize==0)
  {
    aaa <- xyzmat.coords(c) 
    
    lenx = length(aaa$x) 
    leny = length(aaa$y) 
    subX = seq.int(min(x.conc), max(x.conc), length.out = lenx) 
    subY = seq.int(max(y.conc), min(y.conc), length.out = leny) 
    
    
    
    plot_ly(z = c,x = subX, y = subY, type = "surface", 
            # opacity=1, outlinewidth = 10, 
            #showscale = TRUE, 
            
            hoverinfo='z+name', name = "\U03B4 - score",
            
            contours = list(
              y = list(show = FALSE),
              x = list(show = FALSE)
            ), 
            
            #marker = list( 
            
            # color=c("red","white","green"), 
            # cmin = "red", 
            # cmax = "green" 
            # ), 
            colorbar = list( 
              outlinewidth = 0, 
              title = "\U03B4 - score",
              len = 0.24,
              thickness = 19,
              xpad = 3,
              showticklabels = TRUE,
              titlefont = 9,
              outlinewidth = 0.3,
              tickcolor = "#fff",
              tickfont = list(size = 9),
              ticks = "inside"
              #range = c(start.point, end.point) 
            ), 
            colorscale = list(c(0, "rgb(0, 247, 0)"), c(0.5, "rgb(247, 247, 247)"), c(1, "rgb(247, 0, 0)")), 
            cauto = F, 
            cmin = start.point, 
            cmax = end.point,
            contour = list(show = FALSE, color = "#222")
            #reversescale = TRUE, 
            # autocolorscale= FALSE, 
            # colorscale = list("rgb(237,0,0)", "rgb(0,255,0)") 
            
    ) %>% 
      layout(
        title = title3D, 
        scene = list( 
          #camera = list(eye = list(x = -1.25, y = 1.25, z = 1.25)) 
          xaxis = list( 
            title = as.character(drug.row), 
            tickmode = "array", 
            tickvals = seq.int(min(x.conc), max(x.conc), length.out = length(x.conc)), 
            tickfont = list(family = "serif", size = 12), ticks = "outside", 
            ticktext = as.character(y.conc) 
            #textangle = 50 
          ), 
          yaxis = list( 
            title = as.character(drug.col), 
            tickmode = "array", 
            tickvals = seq.int(max(y.conc), min(y.conc), length.out = length(y.conc)), 
            tickfont = list(family = "serif", size = 12), ticks = "outside", 
            ticktext = as.character(x.conc) 
          ), 
          zaxis = list( 
            title =  "\U03B4 - score", 
            range = c(start.point, end.point), 
            tickfont = list(family = "serif", size = 12), ticks = "outside" 
          ) 
        ) 
      )  
    
  } 
  else if (graphnumber == 2 && gridsize2 != 0)
  {
    plot2d = melt(c) 
    
    myPalette <- colorRampPalette(c("green2","white","red1"))(100)
    names(plot2d) <- c("x", "y", "z")
    
    if(is.null(savee2D))
    {
      ggplot(plot2d) + aes(x, y, z = z, fill = z)+
        ggtitle(plot.title) +
        #scale_fill_gradient2(, "\U0394 - score",low=rgb(0,255,0, maxColorValue = 255), high=rgb(255,0, 0,  maxColorValue = 255), guide="colorbar") + 
        geom_raster(interpolate=TRUE) + geom_contour(color = "white", alpha = 0.5) +
        scale_fill_gradientn(expression(delta ~ -score),colours = myPalette, limits=c(start.point, end.point), values = rescale(c(-3, -1, 0, 1, 3))) +
        scale_x_continuous(drug.col, expand = c(0,0),
                           breaks = seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), labels = round(x.conc, 1)) + 
        scale_y_continuous(drug.row, expand = c(0,0),
                           breaks = seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), labels = round(y.conc, 1)) +
        geom_vline(xintercept=seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), linetype="dotted") +
        geom_hline(yintercept=seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), linetype="dotted") +
        theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                           panel.grid.minor = element_blank()) +theme(axis.text=element_text(size=10)) +
        theme(title = element_text(vjust=12))+
        theme(plot.title = element_text(size=18, margin=margin(b = 25, unit = "pt"))) +
        coord_cartesian(xlim = c(brushx[1], brushx[2]), ylim = c(brushy[1], brushy[2]))
    }
    else
    {
      
      gplot2d <- ggplot(plot2d) + aes(x, y, z = z, fill = z)+
        ggtitle(plot.title2) +
        #scale_fill_gradient2(, "\U0394 - score",low=rgb(0,255,0, maxColorValue = 255), high=rgb(255,0, 0,  maxColorValue = 255), guide="colorbar") + 
        geom_raster(interpolate=TRUE) + geom_contour(color = "white", alpha = 0.5) +
        scale_fill_gradientn(expression(delta ~ -score),colours = myPalette, limits=c(start.point, end.point), values = rescale(c(-3, -1, 0, 1, 3))) +
        scale_x_continuous(drug.col, expand = c(0,0),
                           breaks = seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), labels = round(x.conc, 1)) + 
        scale_y_continuous(drug.row, expand = c(0,0),
                           breaks = seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), labels = round(y.conc, 1)) +
        geom_vline(xintercept=seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), linetype="dotted") +
        geom_hline(yintercept=seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), linetype="dotted") +
        theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                           panel.grid.minor = element_blank()) +theme(axis.text=element_text(size=10)) +
        theme(title = element_text(vjust=12))+
        theme(plot.title = element_text(size=18, margin=margin(b = 25, unit = "pt"))) 
      
      if(!is.null(brushx) & !is.null(brushx))
      {
        gplot2d <- gplot2d + coord_cartesian(xlim = c(brushx[1], brushx[2]), ylim = c(brushy[1], brushy[2]))
      }
      
      pdf(name_3D)
      print(gplot2d)
      dev.off()
    }
    
    #c(min(plot2d$x) + (max(plot2d$x) - min(plot2d$x)) * brushx[1], min(plot2d$x) + (max(plot2d$x) - min(plot2d$x)) * brushx[2])
    #ggplotly(v)
    
  }
  else if (graphnumber == 2 && gridsize2 == 0)
  {
    plot2d = melt(c) 
    
    myPalette <- colorRampPalette(c("green2","white","red1"))(100)
    names(plot2d) <- c("x", "y", "z")
    
    if(is.null(savee2D))
    {
      ggplot(plot2d) + aes(x, y, z = z, fill = z)+
        ggtitle(plot.title) +
        #scale_fill_gradient2(, "\U0394 - score",low=rgb(0,255,0, maxColorValue = 255), high=rgb(255,0, 0,  maxColorValue = 255), guide="colorbar") + 
        geom_raster(interpolate=TRUE) + geom_contour(color = "white", alpha = 0.5) +
        scale_fill_gradientn(expression(delta ~ -score),colours = myPalette, limits=c(start.point, end.point), values = rescale(c(-3, -1, 0, 1, 3))) +
        scale_x_continuous(drug.col, expand = c(0,0),
                           breaks = seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), labels = round(x.conc, 1)) + 
        scale_y_continuous(drug.row, expand = c(0,0),
                           breaks = seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), labels = round(y.conc, 1)) +
        #geom_vline(xintercept=seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), linetype="dotted") +
        #geom_hline(yintercept=seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), linetype="dotted") +
        theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                           panel.grid.minor = element_blank()) +theme(axis.text=element_text(size=10)) +
        theme(title = element_text(vjust=12))+
        theme(plot.title = element_text(size=18, margin=margin(b = 25, unit = "pt"))) +
        coord_cartesian(xlim = c(brushx[1], brushx[2]), ylim = c(brushy[1], brushy[2]))
    }
    else
    {
      gplot2d <- ggplot(plot2d) + aes(x, y, z = z, fill = z)+
        ggtitle(plot.title2) +
        #scale_fill_gradient2(, "\U0394 - score",low=rgb(0,255,0, maxColorValue = 255), high=rgb(255,0, 0,  maxColorValue = 255), guide="colorbar") + 
        geom_raster(interpolate=TRUE) + geom_contour(color = "white", alpha = 0.5) +
        scale_fill_gradientn(expression(delta ~ -score),colours = myPalette, limits=c(start.point, end.point), values = rescale(c(-3, -1, 0, 1, 3))) +
        scale_x_continuous(drug.col, expand = c(0,0),
                           breaks = seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), labels = round(x.conc, 1)) + 
        scale_y_continuous(drug.row, expand = c(0,0),
                           breaks = seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), labels = round(y.conc, 1)) +
        #geom_vline(xintercept=seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), linetype="dotted") +
        #geom_hline(yintercept=seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), linetype="dotted") +
        theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                           panel.grid.minor = element_blank()) +theme(axis.text=element_text(size=10)) +
        theme(title = element_text(vjust=12))+
        theme(plot.title = element_text(size=18, margin=margin(b = 25, unit = "pt"))) 
      
      if(!is.null(brushx) & !is.null(brushx))
      {
        gplot2d <- gplot2d + coord_cartesian(xlim = c(brushx[1], brushx[2]), ylim = c(brushy[1], brushy[2]))
      }
      #coord_cartesian(xlim = c(0, 1), ylim = c(0, 1))
      pdf(name_3D)
      print(gplot2d)
      dev.off()
    }
    
    # plot2d = melt(c) 
    # 
    # myPalette <- colorRampPalette(c("green2","white","red1"))(100)
    # names(plot2d) <- c("x", "y", "z")
    # 
    # 
    #   ggplot(plot2d) + aes(x, y, z = z, fill = z)+
    #   ggtitle(plot.title) +
    #   #scale_fill_gradient2(, "\U0394 - score",low=rgb(0,255,0, maxColorValue = 255), high=rgb(255,0, 0,  maxColorValue = 255), guide="colorbar") + 
    #   geom_raster(interpolate=TRUE) + geom_contour(color = "white", alpha = 0.5) +
    #   scale_fill_gradientn("\U0394 - score",colours = myPalette, limits=c(start.point, end.point), values = rescale(c(-3, -1, 0, 1, 3))) +
    #    scale_x_continuous(drug.col, expand = c(0,0),
    #                      breaks = seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), labels = round(x.conc, 1)) + 
    #   scale_y_continuous(drug.row, expand = c(0,0),
    #                      breaks = seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), labels = round(y.conc, 1)) +
    #   #geom_vline(xintercept=seq(min(plot2d$x), max(plot2d$x), by = (max(plot2d$x) - min(plot2d$x)) / (length(x.conc) - 1 )), linetype="dotted") +
    #   #geom_hline(yintercept=seq(min(plot2d$y), max(plot2d$y), by = (max(plot2d$y) - min(plot2d$y)) / (length(y.conc) - 1 )), linetype="dotted") +
    #   theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
    #                      panel.grid.minor = element_blank()) +theme(axis.text=element_text(size=10)) +
    #   theme(plot.title = element_text(size=18, margin=margin(b = 25, unit = "pt"))) +
    # 
    #   coord_cartesian(xlim = c(brushx[1], brushx[2]), ylim = c(brushy[1], brushy[2]))
  }
  # f <- list( family = "Courier New, monospace", size = 25, color = "#7f7f7f") 
  # 
  # p %>% layout( 
  #   colorbar = list( 
  #     list( 
  #       outlinewidth = 0 
  #     ) 
  #   ) 
  # ) 
  
}

